(function ($, Drupal) {

    $.fn.datacheck = function() {
        alert("ajax worked");
        $("#custom-user-details-form").submit();
    };

}(jQuery, Drupal));